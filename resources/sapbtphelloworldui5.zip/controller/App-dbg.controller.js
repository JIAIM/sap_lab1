sap.ui.define([
  "sap/ui/core/mvc/Controller"
], (BaseController) => {
  "use strict";

  return BaseController.extend("sap.btp.helloworldui5.controller.App", {
      onInit() {
      }
  });
});